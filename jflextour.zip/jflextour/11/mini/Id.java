package mini;

/** Abstract syntax for identifiers/variables.
 */
class Id {
    String name;
    Id(String name) {
        this.name = name;
    }
}
